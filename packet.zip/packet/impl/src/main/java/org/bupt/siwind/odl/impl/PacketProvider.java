/*
 * Copyright © 2015 siwind, Inc. and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package org.bupt.siwind.odl.impl;

import org.opendaylight.controller.sal.binding.api.BindingAwareBroker.ProviderContext;
import org.opendaylight.controller.sal.binding.api.BindingAwareProvider;
import org.opendaylight.controller.sal.binding.api.BindingAwareBroker.RpcRegistration;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketProcessingService;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.packet.rev161005.PacketService;
import org.bupt.siwind.odl.impl.SendPacketImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PacketProvider implements BindingAwareProvider, AutoCloseable {

    private static final Logger LOG = LoggerFactory.getLogger(PacketProvider.class);

	private RpcRegistration<PacketService> packetService = null;

    @Override
    public void onSessionInitiated(ProviderContext session) {
        LOG.info("PacketProvider Session Initiated");
		PacketProcessingService packetProcessingService = session.getRpcService(PacketProcessingService.class);

		packetService = session.addRpcImplementation(PacketService.class, new SendPacketImpl(packetProcessingService));
    }

    @Override
    public void close() throws Exception {
        LOG.info("PacketProvider Closed");
		if( packetService != null ){
			packetService.close();
		}
    }

}
