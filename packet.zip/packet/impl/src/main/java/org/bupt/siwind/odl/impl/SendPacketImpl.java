/*
 * Copyright © 2015 siwind, Inc. and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package org.bupt.siwind.odl.impl;

import java.util.concurrent.Future;

import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.packet.rev161005.PacketService;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.packet.rev161005.SendPacketInput;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.packet.rev161005.SendPacketOutput;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.packet.rev161005.SendPacketOutputBuilder;
import org.opendaylight.yangtools.yang.common.RpcResult;
import org.opendaylight.yangtools.yang.common.RpcResultBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.PacketProcessingService;

import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.TransmitPacketInput;
import org.opendaylight.yang.gen.v1.urn.opendaylight.packet.service.rev130709.TransmitPacketInputBuilder;

import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;

import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.node.NodeConnector;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeConnectorRef;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeId;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.NodeRef;
import org.opendaylight.yang.gen.v1.urn.opendaylight.inventory.rev130819.nodes.Node;

public class SendPacketImpl implements PacketService {

	private static final Logger LOG = LoggerFactory.getLogger(SendPacketImpl.class);

	private final PacketProcessingService packetProcessingService;

	public SendPacketImpl(PacketProcessingService packetProcessingService) {
		this.packetProcessingService = packetProcessingService;
	}

	/**
	 * Sends the specified packet on the specified port.
	 *
	 * @param payload
	 *            The payload to be sent.
	 * @param ingress
	 *            The NodeConnector where the payload came from.
	 * @param egress
	 *            The NodeConnector where the payload will go.
	 */
	public void sendPacketOut(byte[] payload, NodeConnectorRef ingress, NodeConnectorRef egress) {
		if (ingress == null || egress == null)
			return;
		InstanceIdentifier<Node> egressNodePath = getNodePath(egress.getValue());
		TransmitPacketInput input = new TransmitPacketInputBuilder() //
				.setPayload(payload) //
				.setNode(new NodeRef(egressNodePath)) //
				.setEgress(egress) //
				.setIngress(ingress) //
				.build();
		packetProcessingService.transmitPacket(input);
	}

	private InstanceIdentifier<Node> getNodePath(final InstanceIdentifier<?> nodeChild) {
		return nodeChild.firstIdentifierOf(Node.class);
	}

	/**
	 * Send packet out
	 * 
	 * @param egressNodeRef
	 * @param egressNodeConnectorRef
	 * @param payload
	 */
	private void packetOut(NodeRef egressNodeRef, NodeConnectorRef egressNodeConnectorRef, byte[] payload) {

		LOG.debug("Siwnd Send packet of size {} out of port {}", payload.length, egressNodeConnectorRef);

		// Construct input for RPC call to packet processing service
		TransmitPacketInput input = new TransmitPacketInputBuilder().setPayload(payload).setNode(egressNodeRef)
				.setEgress(egressNodeConnectorRef).build();
		packetProcessingService.transmitPacket(input);
	}

	// =============================================================
	@Override
	public Future<RpcResult<SendPacketOutput>> sendPacket(SendPacketInput input) {
		SendPacketOutputBuilder packetBuilder = new SendPacketOutputBuilder();

		NodeConnectorRef egress = input.getEgress();
		NodeRef node = input.getNode();
		byte[] payload = input.getRawpacket();
		
		packetOut(node,egress, payload);  //send packet!!
		
		packetBuilder.setResult("OK");
		return RpcResultBuilder.success(packetBuilder.build()).buildFuture();
	}

}
